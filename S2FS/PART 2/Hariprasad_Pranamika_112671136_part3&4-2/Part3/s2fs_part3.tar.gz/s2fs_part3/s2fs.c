
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include<linux/sched.h>
#include <linux/mount.h>
#include <linux/fs.h>
#include <linux/string.h>
#include <linux/uaccess.h>


#define MAGIC_NUMBER 0x19920342
#define FOO "foo"
#define BAR "bar"
#define ERROR -1
#define S2FS "s2fs"
#define HELLO_WORLD "Hello World!\n\0"
#define LIMIT 100
#define DEFAULT_POSIX  S_IRWXU |  S_IRWXG |  S_IRWXO
#define DIR_MODE S_IFDIR | DEFAULT_POSIX
#define FILE_MODE S_IFREG | DEFAULT_POSIX

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Pranamika Hariprasad");

static struct inode *s2fs_make_inode(struct super_block*, umode_t);
static struct dentry *s2fs_create_dir(struct super_block *, struct dentry *, const char *);
static struct dentry *s2fs_create_file(struct super_block *, struct dentry *, const char *);

static int s2fs_open(struct inode *, struct file *);
static ssize_t s2fs_read_file(struct file *, char *, size_t, loff_t *);
static ssize_t s2fs_write_file(struct file *, const char *,size_t, loff_t *);

static int s2fs_fill_super(struct super_block *sb, void *data, int silent)
{
	struct inode *root;
	struct dentry *root_dentry, *foo_dentry;

	sb->s_magic = MAGIC_NUMBER;

	root = s2fs_make_inode (sb, DIR_MODE);
	if (! root) {
		return 0;
	}
	root->i_op = &simple_dir_inode_operations;
	root->i_fop = &simple_dir_operations;

	root_dentry = d_make_root(root);
	if (! root_dentry) {
		iput(root);
		return 0;
	}
	sb->s_root = root_dentry;
	// Part 3.5: Putting it all together
	foo_dentry = s2fs_create_dir(sb, root_dentry, FOO);
	s2fs_create_file(sb, foo_dentry, BAR);
	return 0;	
}

static struct dentry *s2fs_mount(struct file_system_type *fst,
 		int flags, const char *devname, void *data) {
	return mount_nodev(fst, flags, data, s2fs_fill_super);
}

// Meta data about the s2fs file system.
static struct file_system_type s2fs_type = {
        .owner          = THIS_MODULE,
        .name           = S2FS,
        .mount          = s2fs_mount,
        .kill_sb        = kill_litter_super,
};

static int __init s2fs_init(void) {
        printk(KERN_INFO "Init in s2fs\n");
        return register_filesystem(&s2fs_type);
}


static void __exit s2fs_exit(void) {
	printk(KERN_INFO "Exit in s2fs\n");
	unregister_filesystem(&s2fs_type);
}

// Part 3.1: Function to create Inode with given mode
static struct inode *s2fs_make_inode(struct super_block *sb, umode_t mode)
{
	struct inode *inode = new_inode(sb);
	if (inode) {
		inode->i_mode = mode;
		inode->i_blocks = 0;
		inode->i_ino = get_next_ino();
		inode->i_atime = inode->i_mtime = inode->i_ctime = current_time(inode);
	}
	return inode;
}

// Part 3.2: Function to create directory
static struct dentry *s2fs_create_dir(struct super_block *sb,
		struct dentry *parent, const char *dir_name) {
	struct dentry *dentry;
	struct inode *inode;
	struct qstr qstr_name;

	qstr_name.name = dir_name;
	qstr_name.len = strlen (dir_name);
	qstr_name.hash = full_name_hash(parent, dir_name, qstr_name.len);
	dentry = d_alloc(parent, &qstr_name);
	if (! dentry) {
		return 0;
	}

	inode = s2fs_make_inode(sb,  DIR_MODE);
	if (! inode) {
		dput(dentry);
		return 0;
	}
	inode->i_op = &simple_dir_inode_operations;
	inode->i_fop = &simple_dir_operations;
	d_add(dentry, inode);
	return dentry;
}



// Part 3.3: Functions to perform file operations 
static struct file_operations s2fs_file_ops = {
        .open   = s2fs_open,
        .read   = s2fs_read_file,
        .write  = s2fs_write_file,
};

static ssize_t s2fs_read_file(struct file *filp, char *buf, size_t count, loff_t *offset)
{
        int len;
        char tmp[LIMIT];

        strcpy(tmp, HELLO_WORLD);
        len = strlen(tmp);
        if (*offset > len)
                return 0;
        if (count > len - *offset)
                count = len - *offset;

        if (copy_to_user(buf, tmp + *offset, count))
                return -EFAULT;
        *offset += count;
        return count;
}

static int s2fs_open(struct inode *inode, struct file *fp)
{
        return 0;
}

static ssize_t s2fs_write_file(struct file *fp, const char *buffer,
                size_t count, loff_t *offset)
{
        return 0;
}



// Part 3.4: Fuction to create file 
static struct dentry *s2fs_create_file (struct super_block *sb,
		struct dentry *dir, const char *name)
{
	struct dentry *dentry;
	struct inode *inode;
	struct qstr qstr_name;

	qstr_name.name = name;
	qstr_name.len = strlen(name);
	qstr_name.hash = full_name_hash(dir, name, qstr_name.len);

	dentry = d_alloc(dir, &qstr_name);
	if (!dentry) {
		return 0;
	}
	inode = s2fs_make_inode(sb, FILE_MODE);
	if (!inode) {
		dput(dentry);
		return 0;
	}
	inode->i_fop = &s2fs_file_ops;
	d_add(dentry, inode);
	return dentry;
}

module_init(s2fs_init);
module_exit(s2fs_exit);
