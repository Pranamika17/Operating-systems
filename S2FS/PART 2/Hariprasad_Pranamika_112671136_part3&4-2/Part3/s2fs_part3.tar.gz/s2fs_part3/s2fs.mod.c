#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x185f7254, "module_layout" },
	{ 0x53eb6603, "kill_litter_super" },
	{ 0x20664a1b, "unregister_filesystem" },
	{ 0x31bac358, "register_filesystem" },
	{ 0x27e1a049, "printk" },
	{ 0xf798deac, "dput" },
	{ 0xb8438dd9, "iput" },
	{ 0x53ccb2e0, "d_add" },
	{ 0x581d39ae, "d_alloc" },
	{ 0x800fb92b, "full_name_hash" },
	{ 0xec6fbe43, "d_make_root" },
	{ 0xf7038d3c, "simple_dir_operations" },
	{ 0xab396b3, "simple_dir_inode_operations" },
	{ 0xdb7305a1, "__stack_chk_fail" },
	{ 0xb44ad4b3, "_copy_to_user" },
	{ 0xc1f5e2a5, "current_time" },
	{ 0xe953b21f, "get_next_ino" },
	{ 0x5a419377, "new_inode" },
	{ 0x979e36e6, "mount_nodev" },
	{ 0xbdfb6dbb, "__fentry__" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "C35FEA86DD5A8E3C0A275CB");
