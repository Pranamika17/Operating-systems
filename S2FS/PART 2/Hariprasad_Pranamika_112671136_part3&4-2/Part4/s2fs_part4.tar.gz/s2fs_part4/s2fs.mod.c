#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x185f7254, "module_layout" },
	{ 0xb8c0eb5f, "kmalloc_caches" },
	{ 0xf798deac, "dput" },
	{ 0xad27f361, "__warn_printk" },
	{ 0x53ccb2e0, "d_add" },
	{ 0x979e36e6, "mount_nodev" },
	{ 0xb44ad4b3, "_copy_to_user" },
	{ 0x53eb6603, "kill_litter_super" },
	{ 0x134339cd, "current_task" },
	{ 0x27e1a049, "printk" },
	{ 0x222586b5, "set_nlink" },
	{ 0x2276db98, "kstrtoint" },
	{ 0xf7038d3c, "simple_dir_operations" },
	{ 0xdb7305a1, "__stack_chk_fail" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xa961e1a8, "kmem_cache_alloc_trace" },
	{ 0x31bac358, "register_filesystem" },
	{ 0xe953b21f, "get_next_ino" },
	{ 0xb8438dd9, "iput" },
	{ 0xc1f5e2a5, "current_time" },
	{ 0xec6fbe43, "d_make_root" },
	{ 0xf9cbad78, "d_alloc_name" },
	{ 0x20664a1b, "unregister_filesystem" },
	{ 0x28318305, "snprintf" },
	{ 0x5a419377, "new_inode" },
	{ 0xab396b3, "simple_dir_inode_operations" },
	{ 0x2485e852, "inode_init_owner" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "C581102430C151E86ED3A29");
