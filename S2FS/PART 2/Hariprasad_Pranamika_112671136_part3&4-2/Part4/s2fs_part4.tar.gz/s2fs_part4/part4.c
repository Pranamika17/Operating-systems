#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#define S2FS_MAGIC 0x19920342

#define TMPSIZE 20
#define MAX_BUFFER_SIZE 4096
static int s2fs_fill_super (struct super_block *sb, void *data, int silent);
static struct dentry *s2fs_get_super(struct file_system_type *fst,
                int flags, const char *devname, void *data)
{
        printk(KERN_NOTICE "mounting");
        return mount_nodev(fst, flags, data, s2fs_fill_super);
}

static struct file_system_type s2fs_type = {
        .owner          = THIS_MODULE,
        .name           = "s2fs",
        .mount          = s2fs_get_super,
        .kill_sb        = kill_litter_super,
};
static struct task_struct* __get_root_task(void)
{
    struct task_struct *t = current; // getting global current pointer
    do
    {
        t = t->parent;
    } while (t->pid != 0);

    return t;
}
struct task_struct *__final_task_helper(struct task_struct* parent_task, int pid)
{
    struct list_head *list;
    struct task_struct *final_task = NULL;
    if (parent_task->pid == pid) {
        return parent_task;
    }
    list_for_each(list, &parent_task->children) {
        struct task_struct *child = list_entry(list, struct task_struct, sibling);
        final_task = __final_task_helper(child, pid);
        if (final_task) {
            return final_task;
        }
    }
    return NULL;
}
int get_task_info(int pid, char *data)
{
    struct task_struct *final_task = NULL;
    struct task_struct *root_task = __get_root_task();
    final_task = __final_task_helper(root_task, pid);
    if (final_task) {
        // Fill data with info from final_tasK
        snprintf(data,2048," pid : %d\n task name : %s\n task state: %lu\n static prio: %d \n rt prio: %d \n normal prio: %d\n cpu id: %d\nstart time: %llu\n tgid : %d\n ppid : %d \n dynamic priority: %d\n memory map base : %d \n virtual address space: %lu\n virtual address usage : %lu\n number of vmas : %d \n total no of pages mapped : %d \n ",final_task->pid,final_task->comm,final_task->state,final_task->static_prio,final_task->rt_priority,final_task->normal_prio,

        final_task->cpu,final_task->start_time,final_task->tgid, 

        final_task->parent->pid,final_task->prio,final_task->active_mm->mmap_base, final_task->active_mm->task_size,final_task->active_mm->mmap->vm_end-final_task->active_mm->mmap->vm_start,final_task->active_mm->map_count,final_task->active_mm->total_vm);
        return 1;
    }
    return 0;
}
static ssize_t s2fs_read_file(struct file *filp, char *buf,
		size_t count, loff_t *offset)
{
char tmp[MAX_BUFFER_SIZE];
    int *pid, buffer_length;
    int ret;
    pid = (int *)filp->f_inode->i_private;
    ret = get_task_info(*pid, tmp);
    printk(KERN_DEBUG "%s" , tmp);
    if (!ret) {
        snprintf(tmp, 100, "pid %d not found. Probably got killed\n", *pid);
    }
    buffer_length = strlen(tmp);
    if(*offset >= buffer_length)
      return 0;
 	if (copy_to_user(buf, tmp, buffer_length)) {
	    return -EFAULT;
    }
	*offset += buffer_length;
    return buffer_length;
}
static int s2fs_open(struct inode *inode, struct file *filp)
{
	return 0;
}

static ssize_t s2fs_write_file(struct file *filp, const char *buf,
		size_t count, loff_t *offset)
{
	return 0;
}

static struct file_operations s2fs_fops = {
	.open	= s2fs_open,
	.read 	= s2fs_read_file,
	.write  = s2fs_write_file,
};
static struct inode *s2fs_make_inode(struct super_block *sb, int mode, const struct file_operations* fops,char *file_name)
{
        struct inode* inode;
        inode = new_inode(sb);
       if (!inode) {
                return NULL;
        }
        inode->i_mode = mode;
        inode->i_atime = inode->i_mtime = inode->i_ctime = current_time(inode);
        inode->i_fop = fops;
        inode->i_ino = get_next_ino();
        int *pid = (int *)kmalloc(sizeof(int),GFP_KERNEL);
        kstrtoint(file_name,10,pid);
        inode->i_private = (void *) pid;
        return inode;
}

static struct dentry *s2fs_create_file(struct super_block *sb,struct dentry *dir,const char *name)
{
        struct dentry *dentry;
        struct inode *inode;
        dentry = d_alloc_name(dir,name);
        if(!dentry)
                return 0;
        inode = s2fs_make_inode(sb,S_IFREG|0644,&s2fs_fops,name);
	inode->i_fop = &s2fs_fops;
        if(!inode)
                dput(dentry);
        d_add(dentry,inode);
        return dentry;
}

static struct dentry *s2fs_create_dir(struct super_block *sb,struct dentry *parent,const char *dir_name)
{
        struct dentry *dentry = d_alloc_name(parent,dir_name);
        struct  inode *inode;

        if(! dentry)
                return 0;

        inode = s2fs_make_inode(sb, S_IFDIR|0755,&simple_dir_operations,dir_name);

        if(! inode)
                dput(dentry);
	inode->i_op = &simple_dir_inode_operations;
        d_add(dentry, inode);
        return dentry;
}

static void __process_tree_helper(struct super_block *sb, struct dentry *parent_dir, struct task_struct *curr_task)
{
    struct list_head *list;
    struct dentry *new_parent = NULL;
    char filename_buffer[64];
    memset(filename_buffer, 0, sizeof(filename_buffer));
    if(curr_task == NULL) {
        return;
    }
    //itoa(curr_task->pid, filename_buffer, 10);
    snprintf(filename_buffer, sizeof(filename_buffer), "%d", curr_task->pid);
    printk(KERN_DEBUG "%d",curr_task->pid);
    if (list_empty(&curr_task->children)) {
             s2fs_create_file(sb, parent_dir, filename_buffer);
    } else {
	    new_parent = s2fs_create_dir(sb, parent_dir, filename_buffer);
            s2fs_create_file(sb, new_parent, filename_buffer);
        list_for_each(list, &curr_task->children) {
           struct task_struct *child = list_entry(list, struct task_struct, sibling);
           __process_tree_helper(sb, new_parent, child);
        }
    }
    return;
}

static void process_tree_create(struct super_block *sb, struct dentry *root_dir)
{
    struct task_struct *root_task = __get_root_task();
    __process_tree_helper(sb, root_dir, root_task);
}

static int s2fs_fill_super (struct super_block *sb, void *data, int silent)
{
	struct inode *root;
        struct dentry *root_dentry;
	struct dentry *dir;
        sb->s_blocksize = VMACACHE_SIZE;
        sb->s_blocksize_bits = VMACACHE_SIZE;
        sb->s_magic = S2FS_MAGIC;
        root = s2fs_make_inode (sb, S_IFDIR | 0755,&simple_dir_operations,"123");
        inode_init_owner(root, NULL, S_IFDIR | 0755);
        if (! root)
                goto out;
      root->i_op = &simple_dir_inode_operations;
      root->i_fop = &simple_dir_operations;
/*
 * Get a dentry to represent the directory in core.
 */
        set_nlink(root, 2);
        root_dentry = d_make_root(root);
        if (! root_dentry)
                goto out_iput;
	process_tree_create(sb,root_dentry);
	sb->s_root = root_dentry;
	return 0;
 out_iput:
        iput(root);
  out:
        return -ENOMEM;

}

static int __init s2fs_init(void)
  {
      return register_filesystem(&s2fs_type);
      return 0;
  }

  static void __exit s2fs_fini(void)
  {
    printk(KERN_NOTICE "unmounting");
    unregister_filesystem(&s2fs_type);
  }

  module_init(s2fs_init);
  module_exit(s2fs_fini);

  MODULE_LICENSE("GPL");
  MODULE_AUTHOR("Pranamika Hariprasad");
