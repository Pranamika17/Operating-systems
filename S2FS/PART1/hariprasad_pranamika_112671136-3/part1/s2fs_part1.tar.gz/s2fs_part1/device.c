#include <linux/module.h>
#include <linux/kernel.h> /* printk() */
#include <linux/errno.h>   /* error codes */
#include <linux/sched.h>
 
 
MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("Pranamika Hariprasad"); 
/* Declaration of functions */
void device_exit(void);
int device_init(void);
void process_tree_recursion(struct task_struct*,int);   
/* Declaration of the init and exit routines */
module_init(device_init);
module_exit(device_exit);
 
int device_init(void)
{
    struct task_struct *t = current; // getting global current pointer
    printk(KERN_NOTICE "assignment: current process: %s, PID: %d", t->comm, t->pid);
    do
    {
        t = t->parent;
        
    } while (t->pid != 0);
    process_tree_recursion(t,0);    
    return 0;
}

void process_tree_recursion(struct task_struct *t,int n)
{
int i;
struct list_head *list;
if(t == NULL)
return;
printk(KERN_NOTICE "");
for(i =0;i < n;i++)
printk(KERN_CONT " ");
printk(KERN_CONT " %s, (%d)", t->comm,t->pid);
list_for_each(list, &t->children) {
           struct task_struct *tsk = list_entry(list, struct task_struct, sibling);
           process_tree_recursion(tsk,n+1);
        }
}
 
void device_exit(void) {
  printk(KERN_NOTICE "assignment: exiting module");
}

